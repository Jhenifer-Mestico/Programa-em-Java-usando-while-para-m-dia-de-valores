/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grupovalores;

/**
 *
 * @author Jhenifer
 */
import javax.swing.*;
public class GrupoValores {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        // TODO code application logic here
        int  i, quant;
        double  valores, soma;
        
        quant = Integer.parseInt(JOptionPane.showInputDialog(null, 
                "Digite a quantidade de valores desejado:",
                "Valor(es) desejados", JOptionPane.INFORMATION_MESSAGE));
        soma = 0;
        i = 1;
        
        while ( i<=quant){
            valores = Double.parseDouble(JOptionPane.showInputDialog(null, 
                "Por favor, digite um valor:",
                "Valor(es)", JOptionPane.INFORMATION_MESSAGE));
            soma =  soma + valores;
            i = i + 1;
        }
        JOptionPane.showMessageDialog(null, "A média dos valores será: " + soma / quant, "Resultado",
                JOptionPane.INFORMATION_MESSAGE);
    
        
    }
    
}